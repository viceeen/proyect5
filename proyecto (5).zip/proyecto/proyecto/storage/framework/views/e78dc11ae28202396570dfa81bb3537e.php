
<?php $__env->startSection('contenido-principal'); ?>

<div class="row">
    <div class="col">
        <div class="card">
            <div class="card-header">
                Editar Estado
            </div>
            <div class="card-body">
                <form method="POST"action="<?php echo e(route('propuestas.update',$propuesta->id)); ?>">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <label for="estado">Cambiar Estado</label>
                    <input name="estado" id="estado" type="integer">
                    <button type="submit" class="btn btn-outline-secondary">Editar</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/administrador/propuestasedit.blade.php ENDPATH**/ ?>