
<?php $__env->startSection('contenido-principal'); ?>
<div class="row">
    <div class="col">
        <h3>Editar Estudiante</h3>
    </div>
</div>

<form method="POST" action="<?php echo e(route('estudiante.update', $estudiante->rut)); ?>">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    <div class="mb-3">                                                
        <label for="nombre" class= "form-label">Nombre</label>
        <input name="nombre" type="text" id="nombre" class="form-control" value="<?php echo e($estudiante->nombre); ?>">
    </div>
    <div class="mb-3">
        <label for="apellido" class="form-label">Apellido</label>
        <input name="apellido" type="text" id="apellido" class="form-control" value="<?php echo e($estudiante->apellido); ?>">
    </div>
    <div class="mb-3">
        <label for="rut" class="form-label">Rut</label>
        <input name="rut"type="text" id="rut" class="form-control" value="<?php echo e($estudiante->rut); ?>">
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input name="email" type="email" id="email" class="form-control" value="<?php echo e($estudiante->email); ?>">
    </div>
    <div class="mb-3">
        <button type="button" class="btn btn-secondary">Cerrar</button>
        <button type="submit" class="btn btn-primary">Agregar</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/administrador/estudianteedit.blade.php ENDPATH**/ ?>