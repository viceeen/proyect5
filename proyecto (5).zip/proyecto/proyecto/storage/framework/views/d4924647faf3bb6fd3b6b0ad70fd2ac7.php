
<?php $__env->startSection('contenido-principal'); ?>

<table class="table">
                    <thead>
                      <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Rut</th>
                        <th scope="col">Fecha</th>
                        <th scope="col">Documento</th>
                        <th scope="col">Estado</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $propuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($propuesta->id); ?></th>
                        <td><?php echo e($propuesta->estudiante_rut); ?></td>
                        <td><?php echo e($propuesta->fecha); ?></td>
                        <td><?php echo e($propuesta->documento); ?></td>
                        <td><?php echo e($propuesta->estado); ?></td>
                        <td>
                          <a class="btn btn-secondary" href="">Ver propuesta</a>                                                
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/profesor/Estudiantes.blade.php ENDPATH**/ ?>