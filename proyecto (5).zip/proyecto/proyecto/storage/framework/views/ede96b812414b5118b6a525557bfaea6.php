
<?php $__env->startSection('contenido-principal'); ?>

<table class="table table-striped">
    <thead>
        <tr>
            <th scope="col">Rut</th>
            <th scope="col">Nombre</th>
            <th scope="col">Apellido</th>
            <th scope="col">Email</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($estudiante->rut); ?></th>
            <td><?php echo e($estudiante->nombre); ?></td>
            <td><?php echo e($estudiante->apellido); ?></td>
            <td><?php echo e($estudiante->email); ?></td>
            <td>
                <a href="<?php echo e(route('estudiante.edit', $estudiante->rut)); ?>" class="btn btn-secondary">a</a>
            </td>
            <td>
                <form method="POST" action="<?php echo e(route('estudiante.destroy', $estudiante->rut)); ?>">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-secondary">delete</button>


                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/administrador/estudiantes.blade.php ENDPATH**/ ?>