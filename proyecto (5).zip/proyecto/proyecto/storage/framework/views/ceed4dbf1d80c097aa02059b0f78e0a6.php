
<?php $__env->startSection('contenido-principal'); ?>

<div class="row">
    <div class="col">
        <h3>Editar Profesor</h3>

    </div>
</div>
<div class="row">
    <div class="col">
        <div class="card">
            <div class="card-header">
                <?php echo e($profesor->nombre); ?>

            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('profesor.update',$profesor->id)); ?>">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">                                                
                        <label for="profesor_id" class= "form-label">ID</label>
                        <input name="profesor_id" type="text" id="profesor_id" class="form-control" value="<?php echo e($profesor->id); ?>">
                    </div>
                    <div class="mb-3">                                                
                        <label for="profesor_nombre" class= "form-label">Nombre</label>
                        <input name="profesor_nombre" type="text" id="profesor_nombre" class="form-control" value="<?php echo e($profesor->nombre); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="profesor_apellido" class="form-label">Apellido</label>
                        <input name="profesor_apellido" type="text" id="profesor_apellido" class="form-control" value="<?php echo e($profesor->apellido); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="profesor_email" class="form-label">Email</label>
                        <input name="profesor_email" type="text" id="profesor_email" class="form-control" value="<?php echo e($profesor->email); ?>">
                    </div>
                    <div class="mb-3">
                        <button type="button" class="btn btn-secondary">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Editar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/administrador/profesoredit.blade.php ENDPATH**/ ?>