@extends('template.master')
@section('contenido-principal')
<br>
<div class=row>
    <div class="col">
        <div class="card">
            <div class="card-header">
                <div class="row d-flex justify-content-between">
                    <div class="col">
                        <h4>Estudiantes</h4>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">Rut</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Apellido</th>
                        <th scope="col">Email</th>
                      </tr>
                    </thead>
                    <tbody>
                      @foreach($estudiantes as $estudiante)
                      <tr>
                        <th scope="row">{{$estudiante->rut}}</th>
                        <td>{{$estudiante->nombre}}</td>
                        <td>{{$estudiante->apellido}}</td>
                        <td>{{$estudiante->email}}</td>
                        <td>
                          <a href="{{route('estudiante.propuesta',$estudiante->rut)}}" class="btn btn-secondary">Ver propuesta</a>
                        </td>
                      </tr>
                      @endforeach
                    </tbody>
                  </table>

            </div>
        </div>
    </div>
</div>
@endsection