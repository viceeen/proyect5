@extends('template.master')
@section('contenido-principal')

<table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Rut</th>
      <th scope="col">Fecha</th>
      <th scope="col">Documento</th>
      <th scope="col">Estado</th>
    </tr>
  </thead>
  <tbody>
    @foreach($propuestas as $propuesta)
    <tr>
      <th scope="row">{{$propuesta->id}}</th>
      <td>{{$propuesta->estudiante_rut}}</td>
      <td>{{$propuesta->fecha}}</td>
      <td>{{$propuesta->documento}}</td>
      <td>{{$propuesta->estado}}</td>
      <td>
        <a class="btn btn-secondary" href="">Ver propuesta</a>                                                
      </td>
    </tr>
    @endforeach
  </tbody>
</table>




@endsection