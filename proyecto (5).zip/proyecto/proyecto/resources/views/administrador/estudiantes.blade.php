@extends('template.master')
@section('contenido-principal')

<table class="table table-striped">
    <thead>
        <tr>
            <th scope="col">Rut</th>
            <th scope="col">Nombre</th>
            <th scope="col">Apellido</th>
            <th scope="col">Email</th>
        </tr>
    </thead>
    <tbody>
        @foreach($estudiantes as $estudiante)
        <tr>
            <th>{{$estudiante->rut}}</th>
            <td>{{$estudiante->nombre}}</td>
            <td>{{$estudiante->apellido}}</td>
            <td>{{$estudiante->email}}</td>
            <td>
                <a href="{{route('estudiante.edit', $estudiante->rut)}}" class="btn btn-secondary">a</a>
            </td>
            <td>
                <form method="POST" action="{{route('estudiante.destroy', $estudiante->rut)}}">
                @method('DELETE')
                @csrf
                <button type="submit" class="btn btn-secondary">delete</button>


                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection