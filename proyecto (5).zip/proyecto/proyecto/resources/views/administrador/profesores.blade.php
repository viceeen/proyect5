@extends('template.master')
@section('contenido-principal')
<br>
<table class="table table-secondary table-striped">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Nombre</th>
      <th scope="col">Apellido</th>
      <th scope="col">Email</th>
      <th colspan="2"></th>
    </tr>
  </thead>
  <tbody>
    @foreach($profesores as $profesor)
    <tr>
      <th>{{$profesor->id}}</th>
      <th>{{$profesor->nombre}}</th>
      <td>{{$profesor->apellido}}</td>
      <td>{{$profesor->email}}</td>
      <td>
        <a href="{{route('profesor.edit',$profesor->id)}}" class="btn btn-primary">a</a>
      </td>
      <td>
        <form method="POST" action="{{route('profesor.destroy',$profesor->id)}}">
        @method('DELETE')
        @csrf
        <button type="submit" class="btn btn-secondary">delete</button>
        
        </form>
      </td>
    </tr>
    @endforeach
  </tbody>
</table>


@endsection