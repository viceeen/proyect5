@extends('template.master')
@section('contenido-principal')
<table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Rut</th>
      <th scope="col">Fecha</th>
      <th scope="col">Documento</th>
      <th scope="col">Estado</th>
    </tr>
  </thead>
  <tbody>
    @foreach($propuestas as $propuesta)
    <tr>
      <th scope="row">{{$propuesta->id}}</th>
      <td>{{$propuesta->estudiante_rut}}</td>
      <td>{{$propuesta->fecha}}</td>
      <td>
        <a href="   " class="btn btn-secondary"></a>
      </td>
      <td>
        <select class="form-select" aria-label="Default select example" disabled>
          <option value="{{$propuesta->estado}}"@if($propuesta->estado=='0') selected @endif>Esperado Revision</option>
          <option value="{{$propuesta->estado}}"@if($propuesta->estado=='1') selected @endif>Aprobado</option>
          <option value="{{$propuesta->estado}}"@if($propuesta->estado=='2') selected @endif>Rechazado</option>
          <option value="{{$propuesta->estado}}"@if($propuesta->estado=='3') selected @endif>Modificar Propuesta</option>
        </select>
      </td>
      <td>  
        <a href="{{route('propuesta.edit',$propuesta->id)}}" class="btn btn-secondary">Editar</a>       
      </td>
    </tr>
    @endforeach
  </tbody>
</table>


@endsection