@extends('template.master')
@section('contenido-principal')
<br>
<div class="row align-items-center justify-content-center">
    <div class="col-6">
        <div class="card text-bg-secondary">
            <div class="card-header text-center">
                Ingresar Propuesta
                <hr>
                <div class="card-body">
                    <form method="POST" action="{{route('propuesta.store')}}">
                        @csrf
                        <div class="mb-3">
                            <label for="estudiante_rut" class="form-label">Ingrese su rut</label>
                            <input for="estudiante_rut" name="estudiante_rut" id="estudiante_rut"class="form-control">
                        </div>
                        <br>
                        <div class="mb-3">
                            <label for="propuesta" class="form-label">Ingrese Propuesta</label>
                            <input class="form-control"type="file" name="propuesta">
                          </div>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-outline-light " type="submit">Enviar Propuesta</button>
                            </div>
                        </div>
                        
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</div>
@endsection




