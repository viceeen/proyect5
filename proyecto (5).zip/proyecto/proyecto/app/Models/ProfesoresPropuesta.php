<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;


class ProfesoresPropuesta extends Model
{
    use HasFactory;
    protected $table = 'profesores_propuestas';
    
    public function profesores():BelongsToMany{

        return $this -> belongsToMany(Profesor::class);
        
    }
}
